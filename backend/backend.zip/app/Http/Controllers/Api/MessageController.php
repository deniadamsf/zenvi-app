<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Message;
use Illuminate\Http\Request;

class MessageController extends Controller
{
    public function index(Request $request)
    {
        $companyId = $request->user()->company_id;
        
        $messages = Message::where('company_id', $companyId)
            ->orderBy('created_at', 'asc')
            ->get();
            
        return response()->json($messages);
    }

    public function store(Request $request)
    {
        $request->validate([
            'message' => 'required|string',
        ]);

        $message = Message::create([
            'company_id' => $request->user()->company_id,
            'sender_id' => $request->user()->id,
            'message' => $request->message,
        ]);

        // Eager load sender so the frontend gets the name and role
        $message->load('sender');

        return response()->json($message, 201);
    }
}
