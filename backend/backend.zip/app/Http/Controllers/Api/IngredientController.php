<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreIngredientRequest;
use App\Models\Ingredient;
use App\Models\Expense;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class IngredientController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $ingredients = Ingredient::where('company_id', $request->user()->company_id)->get();
        return response()->json(['data' => $ingredients]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreIngredientRequest $request)
    {
        DB::beginTransaction();
        try {
            $ingredient = Ingredient::create([
                'company_id' => $request->user()->company_id,
                'name' => $request->name,
                'unit' => $request->unit,
                'stock_qty' => $request->stock_qty,
                'tolerance_percent' => $request->tolerance_percent ?? 0,
            ]);

            if ($request->filled('price') && $request->price > 0 && $request->stock_qty > 0) {
                Expense::create([
                    'company_id' => $request->user()->company_id,
                    'user_id' => $request->user()->id,
                    'category' => 'Bahan Baku',
                    'amount' => $request->price,
                    'notes' => 'Pembelian Awal: ' . $ingredient->name,
                    'type' => 'ingredient_restock',
                    'reference_id' => $ingredient->id,
                ]);
            }

            DB::commit();

            return response()->json([
                'message' => 'Bahan baku berhasil ditambahkan.',
                'data' => $ingredient
            ], 201);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['message' => 'Gagal menambahkan bahan baku', 'error' => $e->getMessage()], 500);
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(StoreIngredientRequest $request, $id)
    {
        $ingredient = Ingredient::where('company_id', $request->user()->company_id)->findOrFail($id);
        
        $ingredient->update($request->validated());

        return response()->json([
            'message' => 'Bahan baku berhasil diperbarui.',
            'data' => $ingredient
        ]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Request $request, $id)
    {
        $ingredient = Ingredient::where('company_id', $request->user()->company_id)->findOrFail($id);
        $ingredient->delete();

        return response()->json([
            'message' => 'Bahan baku berhasil dihapus.'
        ]);
    }
}
