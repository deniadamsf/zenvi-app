<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\JoinCompanyRequest;
use App\Http\Requests\StoreCompanyRequest;
use App\Models\Company;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class CompanyController extends Controller
{
    /**
     * Get current user's company
     */
    public function index(Request $request)
    {
        $user = $request->user();
        if (!$user->company_id) {
            return response()->json(['message' => 'Anda belum bergabung dengan perusahaan manapun.'], 404);
        }

        return response()->json([
            'data' => $user->load('company')->company
        ]);
    }

    /**
     * Store a newly created company in storage.
     */
    public function store(StoreCompanyRequest $request)
    {
        $user = $request->user();

        // Generate unique code like ZNV-8829
        $code = 'ZNV-' . strtoupper(Str::random(4));
        while (Company::where('code', $code)->exists()) {
            $code = 'ZNV-' . strtoupper(Str::random(4));
        }

        $company = Company::create([
            'name' => $request->name,
            'code' => $code,
        ]);

        // Automatically assign user to this company as Owner and approved
        $user->update([
            'company_id' => $company->id,
            'role' => 'Owner',
            'is_approved' => true,
        ]);

        return response()->json([
            'message' => 'Perusahaan berhasil dibuat.',
            'data' => $company
        ], 201);
    }

    /**
     * Join an existing company using code
     */
    public function join(JoinCompanyRequest $request)
    {
        $user = $request->user();
        
        $company = Company::where('code', $request->code)->first();

        // Join as Cashier, pending approval
        $user->update([
            'company_id' => $company->id,
            'role' => 'Cashier',
            'is_approved' => false,
        ]);

        return response()->json([
            'message' => 'Berhasil bergabung dengan ' . $company->name . '. Menunggu persetujuan Owner.',
            'data' => $company
        ]);
    }

    public function updateLocation(Request $request)
    {
        $user = $request->user();
        if ($user->role !== 'Owner') {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        $request->validate([
            'latitude' => 'required|numeric',
            'longitude' => 'required|numeric',
            'radius_meters' => 'required|integer|min:10',
        ]);

        $company = $user->company;
        $company->update([
            'latitude' => $request->latitude,
            'longitude' => $request->longitude,
            'radius_meters' => $request->radius_meters,
        ]);

        return response()->json([
            'message' => 'Lokasi toko berhasil diperbarui.',
            'data' => $company
        ]);
    }

    public function updateSettings(Request $request)
    {
        $user = $request->user();
        if ($user->role !== 'Owner') {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        $request->validate([
            'require_opname_on_shift_close' => 'required|boolean',
        ]);

        $company = $user->company;
        $company->update([
            'require_opname_on_shift_close' => $request->require_opname_on_shift_close,
        ]);

        return response()->json([
            'message' => 'Pengaturan toko berhasil diperbarui.',
            'data' => $company
        ]);
    }

    public function pendingEmployees(Request $request)
    {
        $user = $request->user();
        if ($user->role !== 'Owner') {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        $pendingUsers = User::where('company_id', $user->company_id)
            ->where('is_approved', false)
            ->get();

        return response()->json($pendingUsers);
    }

    public function approveEmployee(Request $request, $id)
    {
        $user = $request->user();
        if ($user->role !== 'Owner') {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        $employee = User::where('company_id', $user->company_id)->findOrFail($id);
        $employee->update(['is_approved' => true]);

        return response()->json(['message' => 'Karyawan berhasil disetujui.']);
    }
}
