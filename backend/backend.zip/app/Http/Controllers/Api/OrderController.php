<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\SyncOrdersRequest;
use App\Models\Ingredient;
use App\Models\Order;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OrderController extends Controller
{
    /**
     * Get order history (with optional filters for owner dashboard)
     */
    public function index(Request $request)
    {
        $query = Order::with(['items.product', 'user', 'shift.branch'])
            ->where('company_id', $request->user()->company_id);

        // Filter by date
        if ($request->has('date')) {
            $query->whereDate('created_at', $request->date);
        }

        // Filter by user_id
        if ($request->has('user_id')) {
            $query->where('user_id', $request->user_id);
        }

        // Filter by branch_id (via shift)
        if ($request->has('branch_id')) {
            $query->whereHas('shift', function ($q) use ($request) {
                $q->where('branch_id', $request->branch_id);
            });
        }

        $orders = $query->latest()->get();

        return response()->json(['data' => $orders]);
    }

    /**
     * Sync bulk orders from offline-first mobile app
     */
    public function sync(SyncOrdersRequest $request)
    {
        DB::beginTransaction();
        try {
            $companyId = $request->user()->company_id;
            $userId = $request->user()->id;
            $syncedOrders = [];

            foreach ($request->orders as $orderData) {
                // Create Order
                $order = Order::create([
                    'company_id' => $companyId,
                    'user_id' => $userId,
                    'shift_id' => $orderData['shift_id'],
                    'total_amount' => $orderData['total_amount'],
                    'status' => 'synced',
                ]);

                foreach ($orderData['items'] as $itemData) {
                    // Create Order Item
                    $order->items()->create([
                        'product_id' => $itemData['product_id'],
                        'qty' => $itemData['qty'],
                        'subtotal' => $itemData['subtotal'],
                    ]);

                    // BOM Deduction Logic (Antigravity Core)
                    $product = Product::with('ingredients')->find($itemData['product_id']);
                    if ($product) {
                        foreach ($product->ingredients as $ingredientInfo) {
                            $amountToDeduct = $ingredientInfo->pivot->amount_needed * $itemData['qty'];
                            
                            // Find the actual ingredient model to deduct stock
                            $ingredientModel = Ingredient::find($ingredientInfo->id);
                            if ($ingredientModel) {
                                $ingredientModel->decrement('stock_qty', $amountToDeduct);
                            }
                        }
                    }
                }

                $syncedOrders[] = $order->load(['items', 'user', 'shift.branch']);
            }

            DB::commit();

            return response()->json([
                'message' => 'Sinkronisasi pesanan berhasil.',
                'data' => $syncedOrders
            ], 201);
            
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'message' => 'Gagal melakukan sinkronisasi pesanan.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Void an order and restore stock
     */
    public function voidOrder($id, Request $request)
    {
        $order = Order::with('items.product')->where('company_id', $request->user()->company_id)->findOrFail($id);

        if ($order->status === 'voided') {
            return response()->json(['message' => 'Pesanan sudah dibatalkan sebelumnya.'], 400);
        }

        DB::beginTransaction();
        try {
            $order->status = 'voided';
            $order->save();

            // Restore Stock
            foreach ($order->items as $item) {
                $product = Product::with('ingredients')->find($item->product_id);
                if ($product) {
                    foreach ($product->ingredients as $ingredientInfo) {
                        $amountToRestore = $ingredientInfo->pivot->amount_needed * $item->qty;
                        $ingredientModel = Ingredient::find($ingredientInfo->id);
                        if ($ingredientModel) {
                            $ingredientModel->increment('stock_qty', $amountToRestore);
                        }
                    }
                }
            }

            DB::commit();

            return response()->json([
                'message' => 'Pesanan berhasil dibatalkan dan stok telah dikembalikan.',
                'data' => $order->load(['items', 'user', 'shift.branch'])
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'message' => 'Gagal membatalkan pesanan.',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
