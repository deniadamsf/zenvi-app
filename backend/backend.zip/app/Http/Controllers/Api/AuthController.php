<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Laravel\Socialite\Facades\Socialite;

class AuthController extends Controller
{
    /**
     * Authenticate or register user via Google Token from Flutter
     */
    public function googleLogin(Request $request)
    {
        $request->validate([
            'token' => 'required|string', // Token (access_token) from Google Sign In on Flutter
        ]);

        try {
            // Get user data from Google using the token
            $googleUser = Socialite::driver('google')->stateless()->userFromToken($request->token);
            
            // Find or create the user
            $user = User::where('google_id', $googleUser->id)->orWhere('email', $googleUser->email)->first();

            if (!$user) {
                // Register new user (Owner by default, they can create a company later)
                $user = User::create([
                    'google_id' => $googleUser->id,
                    'name' => $googleUser->name,
                    'email' => $googleUser->email,
                    'role' => 'Owner', // Default role for new signups
                    'is_approved' => true, // Owners are auto-approved
                ]);
            } else {
                // Update google_id if it's missing (e.g. they registered previously another way)
                if (!$user->google_id) {
                    $user->update(['google_id' => $googleUser->id]);
                }
            }

            // Create Sanctum Token
            $token = $user->createToken('auth_token')->plainTextToken;

            return response()->json([
                'status' => 'success',
                'message' => 'Login successful',
                'data' => [
                    'user' => $user->load('company'),
                    'access_token' => $token,
                    'token_type' => 'Bearer',
                ]
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Invalid Google Token or Authentication Failed.',
                'error' => $e->getMessage()
            ], 401);
        }
    }

    /**
     * Logout user (Revoke token)
     */
    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();

        return response()->json([
            'status' => 'success',
            'message' => 'Successfully logged out'
        ]);
    }
}
