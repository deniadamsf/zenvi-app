<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Shift;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Ingredient;
use App\Models\IngredientHistory;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;

class ShiftController extends Controller
{
    /**
     * Distance calculation using Haversine formula
     * Returns distance in meters
     */
    private function calculateDistance($lat1, $lon1, $lat2, $lon2)
    {
        $earthRadius = 6371000; // Radius of the earth in meters

        $dLat = deg2rad($lat2 - $lat1);
        $dLon = deg2rad($lon2 - $lon1);

        $a = sin($dLat / 2) * sin($dLat / 2) +
            cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
            sin($dLon / 2) * sin($dLon / 2);

        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));

        return $earthRadius * $c; // Distance in meters
    }

    /**
     * Passive task: Auto-close stale shifts and delete old selfies
     */
    private function runPassiveTasks($companyId)
    {
        // 1. Auto close shifts older than 12 hours
        Shift::where('company_id', $companyId)
            ->where('status', 'active')
            ->where('start_time', '<', Carbon::now()->subHours(12))
            ->update([
                'status' => 'auto_closed',
                'end_time' => DB::raw('DATE_ADD(start_time, INTERVAL 12 HOUR)') // mock end time
            ]);

        // 2. Delete selfies older than 7 days
        $oldShifts = Shift::where('company_id', $companyId)
            ->whereNotNull('selfie_path')
            ->where('start_time', '<', Carbon::now()->subDays(7))
            ->get();

        foreach ($oldShifts as $s) {
            if (Storage::disk('public')->exists($s->selfie_path)) {
                Storage::disk('public')->delete($s->selfie_path);
            }
            $s->update(['selfie_path' => null]);
        }
    }

    /**
     * List all shifts for owner (Log Shift)
     */
    public function index(Request $request)
    {
        $user = $request->user();
        
        $this->runPassiveTasks($user->company_id);

        $query = Shift::where('company_id', $user->company_id)
            ->with('user:id,name');

        if ($request->has('date')) {
            $query->whereDate('start_time', $request->date);
        }
        
        if ($request->has('user_id')) {
            $query->where('user_id', $request->user_id);
        }

        $shifts = $query->orderBy('start_time', 'desc')->get();

        // Calculate revenue for each shift
        $shifts->transform(function ($shift) {
            $revenue = \App\Models\Order::where('shift_id', $shift->id)->sum('total_amount');
            $shift->total_revenue = $revenue;
            
            if ($shift->selfie_path) {
                $shift->selfie_url = url('storage/' . $shift->selfie_path);
            }
            return $shift;
        });

        return response()->json([
            'message' => 'Shift logs retrieved',
            'data' => $shifts
        ]);
    }

    /**
     * Get active shift for current user
     */
    public function active(Request $request)
    {
        $this->runPassiveTasks($request->user()->company_id);

        $activeShift = Shift::where('user_id', $request->user()->id)
            ->where('status', 'active')
            ->first();

        return response()->json([
            'data' => $activeShift
        ]);
    }

    /**
     * Open a new shift
     */
    public function open(Request $request)
    {
        $user = $request->user();
        
        $this->runPassiveTasks($user->company_id);

        // Check if there's already an active shift for this user
        $activeShift = Shift::where('user_id', $user->id)
            ->where('status', 'active')
            ->first();

        if ($activeShift) {
            return response()->json([
                'message' => 'Anda masih memiliki shift yang aktif.',
                'data' => $activeShift
            ], 400);
        }

        $request->validate([
            'opening_balance' => 'required|numeric|min:0',
            'latitude' => 'nullable|numeric',
            'longitude' => 'nullable|numeric',
            'selfie' => 'required|image|max:5120', // Max 5MB
        ]);

        $company = $user->company;
        $branches = \App\Models\Branch::where('company_id', $company->id)->get();
        $validBranchId = null;

        if ($branches->isNotEmpty()) {
            if (!$request->latitude || !$request->longitude) {
                return response()->json(['message' => 'Akses lokasi (GPS) dibutuhkan untuk absensi di toko ini.'], 400);
            }

            $minDistance = PHP_INT_MAX;
            foreach ($branches as $branch) {
                $distance = $this->calculateDistance(
                    $branch->latitude, $branch->longitude,
                    $request->latitude, $request->longitude
                );
                
                if ($distance <= $branch->radius_meters && $distance < $minDistance) {
                    $minDistance = $distance;
                    $validBranchId = $branch->id;
                }
            }

            if (!$validBranchId) {
                return response()->json([
                    'message' => 'Anda berada di luar jangkauan absensi semua cabang toko.'
                ], 403);
            }
        }

        $path = $request->file('selfie')->store('selfies', 'public');

        $shift = Shift::create([
            'company_id' => $user->company_id,
            'user_id' => $user->id,
            'branch_id' => $validBranchId,
            'opening_balance' => $request->opening_balance,
            'start_time' => Carbon::now(),
            'selfie_path' => $path,
            'status' => 'active',
        ]);

        return response()->json([
            'message' => 'Shift berhasil dimulai.',
            'data' => $shift
        ], 201);
    }

    /**
     * Close an active shift (Blind close)
     */
    public function close(Request $request)
    {
        $request->validate([
            'shift_id' => 'required|exists:shifts,id',
            'closing_balance' => 'required|numeric|min:0',
            'opname_data' => 'nullable|array',
            'opname_data.*.ingredient_id' => 'required_with:opname_data|exists:ingredients,id',
            'opname_data.*.actual_qty' => 'required_with:opname_data|numeric|min:0',
        ]);

        $shift = Shift::where('company_id', $request->user()->company_id)
            ->where('user_id', $request->user()->id)
            ->findOrFail($request->shift_id);

        if ($shift->status !== 'active') {
            return response()->json(['message' => 'Shift ini sudah ditutup.'], 400);
        }

        DB::beginTransaction();
        try {
            $shift->update([
                'closing_balance' => $request->closing_balance,
                'end_time' => Carbon::now(),
                'status' => 'closed',
            ]);

            if ($request->has('opname_data')) {
                foreach ($request->opname_data as $data) {
                    $ingredient = Ingredient::where('company_id', $request->user()->company_id)
                        ->find($data['ingredient_id']);
                    
                    if ($ingredient) {
                        $systemQty = $ingredient->stock_qty;
                        $actualQty = $data['actual_qty'];
                        $diff = $actualQty - $systemQty;

                        if ($diff != 0) {
                            $tolerance = $ingredient->tolerance_percent ?? 0;
                            $isWithinTolerance = false;
                            
                            if ($systemQty > 0) {
                                $diffPercent = abs($diff) / $systemQty * 100;
                                if ($diffPercent <= $tolerance) {
                                    $isWithinTolerance = true;
                                }
                            } else {
                                if ($diff > 0) {
                                    $isWithinTolerance = true;
                                }
                            }

                            $ingredient->update(['stock_qty' => $actualQty]);

                            IngredientHistory::create([
                                'company_id' => $request->user()->company_id,
                                'ingredient_id' => $ingredient->id,
                                'user_id' => $request->user()->id,
                                'type' => 'opname',
                                'qty_change' => $diff,
                                'notes' => 'Opname Akhir Shift',
                                'is_suspicious' => !$isWithinTolerance,
                            ]);
                        }
                    }
                }
            }

            DB::commit();

            return response()->json([
                'message' => 'Shift berhasil diakhiri.',
                'data' => $shift
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['message' => 'Gagal mengakhiri shift', 'error' => $e->getMessage()], 500);
        }
    }

    /**
     * Get today's shift summary (Owner only)
     */
    public function summary(Request $request)
    {
        $user = $request->user();
        if ($user->role !== 'Owner') {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        $shifts = Shift::where('company_id', $user->company_id)
            ->whereDate('start_time', Carbon::today())
            ->with('user:id,name')
            ->get();

        $summary = $shifts->map(function ($shift) {
            $revenue = \App\Models\Order::where('shift_id', $shift->id)->sum('total_amount');
            return [
                'employee_name' => $shift->user->name,
                'status' => $shift->status,
                'revenue' => $revenue,
            ];
        });

        return response()->json([
            'message' => 'Ringkasan shift hari ini',
            'data' => $summary,
            'total_revenue' => $summary->sum('revenue')
        ]);
    }
}
