<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Branch;
use Illuminate\Http\Request;

class BranchController extends Controller
{
    public function index(Request $request)
    {
        $branches = Branch::where('company_id', $request->user()->company_id)->get();
        return response()->json(['data' => $branches]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'latitude' => 'required|numeric',
            'longitude' => 'required|numeric',
            'radius_meters' => 'required|integer|min:1',
        ]);

        $branch = Branch::create([
            'company_id' => $request->user()->company_id,
            'name' => $request->name,
            'latitude' => $request->latitude,
            'longitude' => $request->longitude,
            'radius_meters' => $request->radius_meters,
        ]);

        return response()->json(['message' => 'Cabang berhasil ditambahkan', 'data' => $branch], 201);
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'latitude' => 'required|numeric',
            'longitude' => 'required|numeric',
            'radius_meters' => 'required|integer|min:1',
        ]);

        $branch = Branch::where('company_id', $request->user()->company_id)->findOrFail($id);

        $branch->update([
            'name' => $request->name,
            'latitude' => $request->latitude,
            'longitude' => $request->longitude,
            'radius_meters' => $request->radius_meters,
        ]);

        return response()->json(['message' => 'Cabang berhasil diupdate', 'data' => $branch]);
    }

    public function destroy(Request $request, $id)
    {
        $branch = Branch::where('company_id', $request->user()->company_id)->findOrFail($id);
        $branch->delete();

        return response()->json(['message' => 'Cabang berhasil dihapus']);
    }
}
