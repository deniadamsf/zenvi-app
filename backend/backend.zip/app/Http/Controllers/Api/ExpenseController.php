<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Expense;
use App\Models\Ingredient;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ExpenseController extends Controller
{
    public function index(Request $request)
    {
        $expenses = Expense::where('company_id', $request->user()->company_id)
            ->with('user:id,name')
            ->orderBy('created_at', 'desc')
            ->get();

        return response()->json([
            'message' => 'Expenses retrieved successfully',
            'data' => $expenses
        ]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'expense_type' => 'required|string',
            'amount' => 'required|numeric|min:0',
            'description' => 'nullable|string',
            'ingredient_id' => 'nullable|exists:ingredients,id',
            'qty_added' => 'nullable|numeric|min:0'
        ]);

        $user = $request->user();

        DB::beginTransaction();
        try {
            $expense = Expense::create([
                'company_id' => $user->company_id,
                'user_id' => $user->id,
                'expense_type' => $request->expense_type,
                'amount' => $request->amount,
                'description' => $request->description,
            ]);

            // If it's an ingredient restock, update the stock
            if ($request->expense_type === 'ingredient_restock' && $request->ingredient_id && $request->qty_added) {
                $ingredient = Ingredient::where('id', $request->ingredient_id)
                    ->where('company_id', $user->company_id)
                    ->firstOrFail();

                $ingredient->increment('stock_qty', $request->qty_added);
            }

            DB::commit();

            return response()->json([
                'message' => 'Expense created successfully',
                'data' => $expense
            ], 201);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'message' => 'Failed to create expense: ' . $e->getMessage()
            ], 500);
        }
    }

    public function financialReport(Request $request)
    {
        $companyId = $request->user()->company_id;

        $totalSales = Order::where('company_id', $companyId)->sum('total_amount');
        $totalExpenses = Expense::where('company_id', $companyId)->sum('amount');
        $netProfit = $totalSales - $totalExpenses;

        return response()->json([
            'message' => 'Financial report generated',
            'data' => [
                'total_sales' => $totalSales,
                'total_expenses' => $totalExpenses,
                'net_profit' => $netProfit,
            ]
        ]);
    }
}
