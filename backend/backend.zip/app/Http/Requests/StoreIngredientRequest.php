<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreIngredientRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->company_id !== null;
    }

    public function rules(): array
    {
        return [
            'name' => 'required|string|max:255',
            'unit' => 'required|string|max:50',
            'stock_qty' => 'required|numeric|min:0',
            'tolerance_percent' => 'nullable|numeric|min:0|max:100',
            'price' => 'nullable|numeric|min:0',
        ];
    }
}
