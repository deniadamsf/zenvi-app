<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class SyncOrdersRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->company_id !== null;
    }

    public function rules(): array
    {
        return [
            'orders' => 'required|array',
            'orders.*.shift_id' => 'required|exists:shifts,id',
            'orders.*.total_amount' => 'required|numeric|min:0',
            'orders.*.items' => 'required|array|min:1',
            'orders.*.items.*.product_id' => 'required|exists:products,id',
            'orders.*.items.*.qty' => 'required|integer|min:1',
            'orders.*.items.*.subtotal' => 'required|numeric|min:0',
        ];
    }
}
