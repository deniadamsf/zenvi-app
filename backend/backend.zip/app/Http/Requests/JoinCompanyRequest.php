<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class JoinCompanyRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'code' => 'required|string|exists:companies,code',
        ];
    }

    public function messages(): array
    {
        return [
            'code.exists' => 'Kode perusahaan tidak ditemukan.',
        ];
    }
}
