<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\CompanyController;
use App\Http\Controllers\Api\IngredientController;
use App\Http\Controllers\Api\OrderController;
use App\Http\Controllers\Api\ProductController;
use App\Http\Controllers\Api\ShiftController;
use App\Http\Controllers\Api\ExpenseController;
use App\Http\Controllers\Api\StockManagementController;
use App\Http\Controllers\Api\MessageController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
*/

// Public Routes
Route::post('/auth/google', [AuthController::class, 'googleLogin']);

// Protected Routes (Require valid Sanctum Token)
Route::middleware('auth:sanctum')->group(function () {
    Route::get('/user', function (Request $request) {
        return $request->user()->load('company');
    });
    Route::post('/logout', [AuthController::class, 'logout']);
    
    // Company APIs
    Route::get('/companies/mine', [CompanyController::class, 'index']);
    Route::post('/companies', [CompanyController::class, 'store']);
    Route::post('/companies/join', [CompanyController::class, 'join']);
    Route::post('/companies/settings', [CompanyController::class, 'updateSettings']);
    Route::get('/companies/employees/pending', [CompanyController::class, 'pendingEmployees']);
    Route::post('/companies/employees/{id}/approve', [CompanyController::class, 'approveEmployee']);
    // Branch APIs
    Route::apiResource('branches', App\Http\Controllers\Api\BranchController::class);
    // Master Data APIs
    Route::apiResource('ingredients', IngredientController::class);
    Route::apiResource('products', ProductController::class);

    // Shift APIs
    // Shift APIs
    Route::get('/shifts', [ShiftController::class, 'index']);
    Route::get('/shifts/active', [ShiftController::class, 'active']);
    Route::get('/shifts/summary', [ShiftController::class, 'summary']);
    Route::post('/shifts/open', [ShiftController::class, 'open']);
    Route::post('/shifts/close', [ShiftController::class, 'close']);

    // Order (Sync) APIs
    Route::get('/orders', [OrderController::class, 'index']);
    Route::post('/orders/sync', [OrderController::class, 'sync']);
    Route::post('/orders/{id}/void', [OrderController::class, 'voidOrder']);

    // Stock Management APIs (Owner Only)
    Route::get('/stock/history', [StockManagementController::class, 'history']);
    Route::post('/stock/restock', [StockManagementController::class, 'restock']);
    Route::post('/stock/wastage', [StockManagementController::class, 'wastage']);
    Route::post('/stock/opname', [StockManagementController::class, 'opname']);

    // Expense & Financial APIs
    // Expense & Financial APIs
    Route::apiResource('expenses', ExpenseController::class)->only(['index', 'store']);
    Route::get('/reports/financial', [ExpenseController::class, 'financialReport']);

    // Chat API
    Route::get('/chat', [MessageController::class, 'index']);
    Route::post('/chat', [MessageController::class, 'store']);
});
