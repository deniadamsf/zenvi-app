<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Ingredient;
use App\Models\IngredientHistory;
use App\Models\Expense;
use App\Services\FirebaseNotificationService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StockManagementController extends Controller
{
    private function checkStockAccess(Request $request)
    {
        $user = $request->user();
        if ($user->role === 'Owner') {
            return;
        }

        if (!$user->hasPermission('can_access_stock')) {
            abort(403, 'Anda tidak memiliki hak akses untuk mengelola stok bahan.');
        }
    }

    public function restock(Request $request)
    {
        $this->checkStockAccess($request);

        $request->validate([
            'ingredient_id' => 'required|exists:ingredients,id',
            'qty' => 'required|numeric|min:0.01',
            'total_price' => 'required|numeric|min:0',
            'notes' => 'nullable|string',
        ]);

        DB::beginTransaction();
        try {
            $ingredient = Ingredient::where('company_id', $request->user()->company_id)
                ->findOrFail($request->ingredient_id);

            $ingredient->increment('stock_qty', $request->qty);

            IngredientHistory::create([
                'company_id' => $request->user()->company_id,
                'ingredient_id' => $ingredient->id,
                'user_id' => $request->user()->id,
                'type' => 'restock',
                'qty_change' => $request->qty,
                'notes' => $request->notes ?? 'Restock via Admin Stock',
            ]);

            Expense::create([
                'company_id' => $request->user()->company_id,
                'user_id' => $request->user()->id,
                'expense_type' => 'ingredient_restock',
                'amount' => $request->total_price,
                'description' => 'Pembelian bahan baku: ' . $ingredient->name . ' (' . $request->qty . ' ' . $ingredient->unit . ')',
            ]);

            DB::commit();

            return response()->json([
                'message' => 'Restock berhasil.',
                'data' => $ingredient->fresh()
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['message' => 'Gagal melakukan restock.', 'error' => $e->getMessage()], 500);
        }
    }

    public function wastage(Request $request)
    {
        $this->checkStockAccess($request);

        $request->validate([
            'ingredient_id' => 'required|exists:ingredients,id',
            'qty' => 'required|numeric|min:0.01',
            'notes' => 'required|string',
        ]);

        DB::beginTransaction();
        try {
            $ingredient = Ingredient::where('company_id', $request->user()->company_id)
                ->findOrFail($request->ingredient_id);

            if ($ingredient->stock_qty < $request->qty) {
                return response()->json(['message' => 'Stok tidak mencukupi untuk wastage.'], 400);
            }

            $ingredient->decrement('stock_qty', $request->qty);

            IngredientHistory::create([
                'company_id' => $request->user()->company_id,
                'ingredient_id' => $ingredient->id,
                'user_id' => $request->user()->id,
                'type' => 'wastage',
                'qty_change' => -$request->qty,
                'notes' => $request->notes,
            ]);

            DB::commit();

            $fresh = $ingredient->fresh();
            if ($fresh->stock_qty <= ($fresh->min_stock ?? 5)) {
                try {
                    FirebaseNotificationService::sendToCompany(
                        $request->user()->company_id,
                        'Peringatan Stok Rendah!',
                        "Bahan '{$fresh->name}' tersisa {$fresh->stock_qty} {$fresh->unit} setelah pencatatan wastage. Segera lakukan restock!",
                        'stock',
                        ['ingredient_id' => $fresh->id, 'type' => 'low_stock', 'route' => '/stock']
                    );
                } catch (\Exception $e) {
                    \Log::warning('Low stock notification failed: ' . $e->getMessage());
                }
            }

            return response()->json([
                'message' => 'Wastage berhasil dicatat.',
                'data' => $fresh
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['message' => 'Gagal mencatat wastage.', 'error' => $e->getMessage()], 500);
        }
    }

    public function opname(Request $request)
    {
        $this->checkStockAccess($request);

        $request->validate([
            'ingredient_id' => 'required|exists:ingredients,id',
            'actual_qty' => 'required|numeric|min:0',
            'notes' => 'nullable|string',
        ]);

        DB::beginTransaction();
        try {
            $ingredient = Ingredient::where('company_id', $request->user()->company_id)
                ->findOrFail($request->ingredient_id);

            $systemQty = $ingredient->stock_qty;
            $actualQty = $request->actual_qty;
            $diff = $actualQty - $systemQty;

            if ($diff == 0) {
                return response()->json(['message' => 'Stok fisik sama dengan sistem. Tidak ada penyesuaian.']);
            }

            // Calculate percentage difference relative to system qty
            // If system qty is 0, any diff is 100% technically, so we handle it.
            $tolerance = $ingredient->tolerance_percent ?? 0;
            $isWithinTolerance = false;
            
            if ($systemQty > 0) {
                $diffPercent = abs($diff) / $systemQty * 100;
                if ($diffPercent <= $tolerance) {
                    $isWithinTolerance = true;
                }
            } else {
                // If system qty is 0, we can't really calculate a percentage loss. Any positive difference is an addition (restock-like).
                // Usually tolerance is for loss, but we just allow it if diff is positive.
                if ($diff > 0) {
                     $isWithinTolerance = true; // Auto adjust if finding unexpected extra stock when system is 0
                }
            }

            // If we want to strictly require Owner (which it is, since checkOwnerRole is active),
            // The Owner is doing it, so we always adjust. But we can tag it as 'Auto-Adjustment' in notes if it's within tolerance
            // just to give context in reports.
            
            $notePrefix = $isWithinTolerance ? '[Auto-Adjustment - Toleransi] ' : '[Penyesuaian Manual] ';
            $finalNotes = $notePrefix . ($request->notes ?? 'Selisih opname');

            $ingredient->update(['stock_qty' => $actualQty]);

            IngredientHistory::create([
                'company_id' => $request->user()->company_id,
                'ingredient_id' => $ingredient->id,
                'user_id' => $request->user()->id,
                'type' => 'opname',
                'qty_change' => $diff,
                'notes' => $finalNotes,
            ]);

            DB::commit();

            $fresh = $ingredient->fresh();
            if ($fresh->stock_qty <= ($fresh->min_stock ?? 5)) {
                try {
                    FirebaseNotificationService::sendToCompany(
                        $request->user()->company_id,
                        'Peringatan Stok Rendah!',
                        "Bahan '{$fresh->name}' tersisa {$fresh->stock_qty} {$fresh->unit} setelah stock opname. Segera lakukan restock!",
                        'stock',
                        ['ingredient_id' => $fresh->id, 'type' => 'low_stock', 'route' => '/stock']
                    );
                } catch (\Exception $e) {
                    \Log::warning('Low stock notification failed: ' . $e->getMessage());
                }
            }

            return response()->json([
                'message' => 'Stock opname berhasil dicatat.',
                'data' => $fresh
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['message' => 'Gagal melakukan stock opname.', 'error' => $e->getMessage()], 500);
        }
    }

    public function history(Request $request)
    {
        $this->checkStockAccess($request);

        $histories = IngredientHistory::where('company_id', $request->user()->company_id)
            ->with(['user:id,name', 'ingredient:id,name,unit'])
            ->orderBy('created_at', 'desc')
            ->get();

        return response()->json([
            'message' => 'Stock histories retrieved',
            'data' => $histories
        ]);
    }
}
