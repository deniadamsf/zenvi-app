<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\SyncOrdersRequest;
use App\Models\Ingredient;
use App\Models\Member;
use App\Models\Order;
use App\Models\Product;
use App\Services\FirebaseNotificationService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OrderController extends Controller
{
    /**
     * Get order history (with optional filters for owner dashboard)
     */
    public function index(Request $request)
    {
        $query = Order::with(['items.product', 'user', 'servicedBy', 'shift.branch', 'member'])
            ->where('company_id', $request->user()->company_id);

        // Filter by date
        if ($request->has('date')) {
            $query->whereDate('created_at', $request->date);
        }

        // Filter by member_id
        if ($request->has('member_id')) {
            $query->where('member_id', $request->member_id);
        }

        // Filter by user_id or serviced_by_user_id
        if ($request->has('user_id')) {
            $userId = $request->user_id;
            $query->where(function($q) use ($userId) {
                $q->where('user_id', $userId)->orWhere('serviced_by_user_id', $userId);
            });
        }

        // Filter by branch_id (via shift)
        if ($request->has('branch_id')) {
            $query->whereHas('shift', function ($q) use ($request) {
                $q->where('branch_id', $request->branch_id);
            });
        }

        $orders = $query->latest()->get();

        return response()->json(['data' => $orders]);
    }

    /**
     * Sync bulk orders from offline-first mobile app
     */
    public function sync(SyncOrdersRequest $request)
    {
        DB::beginTransaction();
        try {
            $companyId = $request->user()->company_id;
            $userId = $request->user()->id;
            $syncedOrders = [];
            $lowStockIngredients = [];

            foreach ($request->orders as $orderData) {
                // Create Order
                $order = Order::create([
                    'company_id' => $companyId,
                    'user_id' => $userId,
                    'serviced_by_user_id' => $orderData['serviced_by_user_id'] ?? null,
                    'member_id' => $orderData['member_id'] ?? null,
                    'member_name' => $orderData['member_name'] ?? null,
                    'member_phone' => $orderData['member_phone'] ?? null,
                    'member_discount_amount' => $orderData['member_discount_amount'] ?? 0,
                    'shift_id' => $orderData['shift_id'],
                    'total_amount' => $orderData['total_amount'],
                    'payment_method' => $orderData['payment_method'] ?? 'cash',
                    'cash_received' => $orderData['cash_received'] ?? null,
                    'cash_change' => $orderData['cash_change'] ?? null,
                    'status' => 'synced',
                ]);

                // Update Member statistics and points if member_id is provided
                if (!empty($orderData['member_id'])) {
                    $member = Member::where('company_id', $companyId)->find($orderData['member_id']);
                    if ($member) {
                        $earnedPoints = (int) floor($orderData['total_amount'] / 1000);
                        $member->increment('total_spend', $orderData['total_amount']);
                        $member->increment('total_transactions', 1);
                        if ($earnedPoints > 0) {
                            $member->increment('points', $earnedPoints);
                        }
                    }
                }

                foreach ($orderData['items'] as $itemData) {
                    // Create Order Item
                    $order->items()->create([
                        'product_id' => $itemData['product_id'],
                        'variant_name' => $itemData['variant_name'] ?? null,
                        'qty' => $itemData['qty'],
                        'subtotal' => $itemData['subtotal'],
                    ]);

                    // BOM Deduction Logic (Antigravity Core)
                    $product = Product::with('ingredients')->find($itemData['product_id']);
                    if ($product) {
                        foreach ($product->ingredients as $ingredientInfo) {
                            $amountToDeduct = $ingredientInfo->pivot->amount_needed * $itemData['qty'];
                            
                            $ingredientModel = Ingredient::find($ingredientInfo->id);
                            if ($ingredientModel) {
                                if ($ingredientModel->stock_qty >= $amountToDeduct) {
                                    $ingredientModel->decrement('stock_qty', $amountToDeduct);
                                } else {
                                    $ingredientModel->update(['stock_qty' => 0]);
                                    \Illuminate\Support\Facades\Log::warning("Insufficient stock for ingredient {$ingredientModel->id} during order sync.");
                                }

                                $freshIngredient = $ingredientModel->fresh();
                                $minStock = $freshIngredient->min_stock ?? 5;
                                if ($freshIngredient->stock_qty <= $minStock) {
                                    $lowStockIngredients[$freshIngredient->id] = $freshIngredient;
                                }
                            }
                        }
                    }
                }

                $syncedOrders[] = $order->load(['items', 'user', 'shift.branch', 'member']);
            }

            DB::commit();

            // Push Notification for Low Stock (to Owner & Employees)
            if (!empty($lowStockIngredients)) {
                try {
                    foreach ($lowStockIngredients as $ing) {
                        FirebaseNotificationService::sendToCompany(
                            $companyId,
                            'Peringatan Stok Rendah!',
                            "Bahan '{$ing->name}' tersisa {$ing->stock_qty} {$ing->unit}. Segera lakukan restock!",
                            'stock',
                            ['ingredient_id' => $ing->id, 'type' => 'low_stock', 'route' => '/stock']
                        );
                    }
                } catch (\Exception $e) {
                    \Log::warning('Low stock notification failed: ' . $e->getMessage());
                }
            }

            return response()->json([
                'message' => 'Sinkronisasi pesanan berhasil.',
                'data' => $syncedOrders
            ], 201);
            
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'message' => 'Gagal melakukan sinkronisasi pesanan.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Void an order and restore stock
     */
    public function voidOrder($id, Request $request)
    {
        if ($request->user()->role !== 'Owner') {
            return response()->json(['message' => 'Unauthorized'], 403);
        }

        $order = Order::with('items.product')->where('company_id', $request->user()->company_id)->findOrFail($id);

        if ($order->status === 'voided') {
            return response()->json(['message' => 'Pesanan sudah dibatalkan sebelumnya.'], 400);
        }

        DB::beginTransaction();
        try {
            $order->status = 'voided';
            $order->save();

            // Revert member spend & transactions if applicable
            if ($order->member_id) {
                $member = Member::where('company_id', $request->user()->company_id)->find($order->member_id);
                if ($member) {
                    $earnedPoints = (int) floor($order->total_amount / 1000);
                    $member->decrement('total_spend', min($member->total_spend, $order->total_amount));
                    if ($member->total_transactions > 0) {
                        $member->decrement('total_transactions', 1);
                    }
                    if ($earnedPoints > 0 && $member->points >= $earnedPoints) {
                        $member->decrement('points', $earnedPoints);
                    }
                }
            }

            // Restore Stock
            foreach ($order->items as $item) {
                $product = Product::with('ingredients')->find($item->product_id);
                if ($product) {
                    foreach ($product->ingredients as $ingredientInfo) {
                        $amountToRestore = $ingredientInfo->pivot->amount_needed * $item->qty;
                        $ingredientModel = Ingredient::find($ingredientInfo->id);
                        if ($ingredientModel) {
                            $ingredientModel->increment('stock_qty', $amountToRestore);
                        }
                    }
                }
            }

            DB::commit();

            return response()->json([
                'message' => 'Pesanan berhasil dibatalkan dan stok telah dikembalikan.',
                'data' => $order->load(['items', 'user', 'shift.branch', 'member'])
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'message' => 'Gagal membatalkan pesanan.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get orders specifically for Kitchen Display System (KDS)
     */
    public function getKdsOrders(Request $request)
    {
        $orders = Order::with(['items.product', 'user', 'servicedBy'])
            ->where('company_id', $request->user()->company_id)
            ->where('status', 'synced')
            ->whereIn('kds_status', ['pending', 'preparing'])
            ->latest()
            ->get();

        return response()->json(['data' => $orders]);
    }

    /**
     * Update the KDS status of an order
     */
    public function updateKdsStatus($id, Request $request)
    {
        $request->validate([
            'kds_status' => 'required|in:pending,preparing,ready',
        ]);

        $order = Order::where('company_id', $request->user()->company_id)->findOrFail($id);
        $order->kds_status = $request->kds_status;
        $order->save();

        return response()->json([
            'message' => 'Status pesanan KDS berhasil diupdate.',
            'data' => $order
        ]);
    }
}
