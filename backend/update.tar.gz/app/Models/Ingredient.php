<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ingredient extends Model
{
    use HasFactory;

    protected $fillable = [
        'company_id',
        'name',
        'unit',
        'stock_qty',
        'min_stock',
        'tolerance_percent',
    ];

    public function company()
    {
        return $this->belongsTo(Company::class);
    }
}
