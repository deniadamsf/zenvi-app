<!DOCTYPE html>
<html lang="{{ $company ? $company->default_language : 'id' }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>{{ $company ? $company->name . ' - ' . ($company->default_language == 'en' ? 'Digital Menu' : 'Menu Digital') : 'Menu Digital - Zenvi' }}</title>
    <meta name="description" content="{{ $company ? $company->qr_menu_description : '' }}">
    <meta name="theme-color" content="#ffffff">

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Lucide Icons -->
    <script src="https://unpkg.com/lucide@latest"></script>
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        :root {
            --primary: #000000;
            --primary-light: #f3f4f6;
            --bg-body: #f9fafb;
            --card-bg: #ffffff;
            --text-main: #111827;
            --text-muted: #6b7280;
            --border-color: #e5e7eb;
            --radius-lg: 16px;
            --radius-md: 12px;
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        }

        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Inter', sans-serif; -webkit-tap-highlight-color: transparent; }
        body { background-color: var(--bg-body); color: var(--text-main); line-height: 1.5; padding-bottom: 80px; }
        .container { max-width: 640px; margin: 0 auto; background: var(--bg-body); min-height: 100vh; position: relative; }
        
        .hidden { display: none !important; }
        .flex { display: flex; } .items-center { align-items: center; }
        .text-sm { font-size: 0.875rem; } .font-bold { font-weight: 700; } .font-semibold { font-weight: 600; }
        .text-muted { color: var(--text-muted); }
        .w-full { width: 100%; }

        /* Header */
        .header { background: var(--card-bg); padding: 24px 20px; border-bottom: 1px solid var(--border-color); }
        .store-profile { display: flex; align-items: center; gap: 16px; margin-bottom: 16px; }
        .store-logo { width: 64px; height: 64px; border-radius: 50%; object-fit: cover; border: 1px solid var(--border-color); }
        .store-logo-placeholder { width: 64px; height: 64px; border-radius: 50%; background: var(--primary-light); display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 24px; color: var(--text-muted); }
        .store-info { flex: 1; min-width: 0; }
        .store-name { font-size: 1.25rem; font-weight: 800; margin-bottom: 4px; }
        .store-desc { font-size: 0.875rem; color: var(--text-muted); }

        /* Navigation Tabs */
        .nav-tabs { display: flex; gap: 8px; overflow-x: auto; padding: 12px 20px; background: var(--card-bg); border-bottom: 1px solid var(--border-color); position: sticky; top: 0; z-index: 10; scrollbar-width: none; }
        .nav-tabs::-webkit-scrollbar { display: none; }
        .tab-btn { white-space: nowrap; padding: 8px 16px; border-radius: 20px; font-size: 0.875rem; font-weight: 600; cursor: pointer; border: 1px solid transparent; background: transparent; color: var(--text-muted); transition: all 0.2s; }
        .tab-btn.active { background: var(--primary); color: white; }
        
        .section-content { padding: 20px; animation: fadeIn 0.3s ease; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(5px); } to { opacity: 1; transform: translateY(0); } }

        /* Search */
        .search-box { position: relative; margin-bottom: 16px; }
        .search-icon { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--text-muted); width: 18px; height: 18px; }
        .search-input { width: 100%; padding: 12px 12px 12px 40px; border-radius: var(--radius-md); border: 1px solid var(--border-color); background: var(--card-bg); font-size: 0.875rem; outline: none; transition: border-color 0.2s; }
        .search-input:focus { border-color: var(--primary); }

        /* Categories */
        .categories { display: flex; gap: 8px; overflow-x: auto; margin-bottom: 20px; scrollbar-width: none; }
        .categories::-webkit-scrollbar { display: none; }
        .cat-btn { padding: 6px 12px; border-radius: 16px; border: 1px solid var(--border-color); background: var(--card-bg); font-size: 0.8125rem; font-weight: 500; cursor: pointer; white-space: nowrap; color: var(--text-muted); }
        .cat-btn.active { border-color: var(--primary); color: var(--primary); background: var(--primary-light); font-weight: 600; }

        /* Product Grid */
        .menu-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; }
        .product-card { background: var(--card-bg); border: 1px solid var(--border-color); border-radius: var(--radius-md); overflow: hidden; display: flex; flex-direction: column; cursor: pointer; transition: transform 0.2s, box-shadow 0.2s; }
        .product-card:hover { transform: translateY(-2px); box-shadow: var(--shadow-md); }
        .product-img-box { position: relative; width: 100%; padding-top: 100%; background: var(--primary-light); }
        .product-img { position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; }
        .product-info { padding: 12px; flex: 1; display: flex; flex-direction: column; }
        .product-title { font-size: 0.875rem; font-weight: 600; margin-bottom: 4px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
        .product-price { font-size: 0.9375rem; font-weight: 700; color: var(--primary); margin-top: auto; }
        
        /* Clean Form */
        .form-group { margin-bottom: 16px; }
        .form-label { display: block; font-size: 0.875rem; font-weight: 600; margin-bottom: 6px; }
        .form-input { width: 100%; padding: 10px 12px; border: 1px solid var(--border-color); border-radius: var(--radius-md); font-size: 0.875rem; outline: none; }
        .form-input:focus { border-color: var(--primary); }
        .btn-primary { width: 100%; padding: 12px; background: var(--primary); color: white; border: none; border-radius: var(--radius-md); font-weight: 600; cursor: pointer; }
        .btn-primary:hover { opacity: 0.9; }

        /* Simple Modal */
        .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 100; display: flex; justify-content: center; align-items: flex-end; opacity: 0; pointer-events: none; transition: opacity 0.3s; }
        .modal-overlay.active { opacity: 1; pointer-events: auto; }
        .modal-content { background: var(--card-bg); width: 100%; max-width: 640px; border-top-left-radius: 20px; border-top-right-radius: 20px; padding: 24px 20px; transform: translateY(100%); transition: transform 0.3s cubic-bezier(0.16, 1, 0.3, 1); max-height: 90vh; overflow-y: auto; position: relative; }
        .modal-overlay.active .modal-content { transform: translateY(0); }
        .modal-close { position: absolute; top: 16px; right: 16px; background: var(--primary-light); border: none; border-radius: 50%; width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; cursor: pointer; }

        @media (min-width: 641px) {
            .modal-overlay { align-items: center; }
            .modal-content { border-radius: 20px; transform: scale(0.95); width: 90%; }
            .modal-overlay.active .modal-content { transform: scale(1); }
        }
    </style>
</head>
<body>
    @php
        $lang = $company && $company->default_language == 'en' ? 'en' : 'id';
        $t = [
            'menu' => $lang == 'en' ? 'Menu' : 'Menu',
            'member' => $lang == 'en' ? 'Member' : 'Member',
            'reservation' => $lang == 'en' ? 'Reservation' : 'Reservasi',
            'search' => $lang == 'en' ? 'Search items...' : 'Cari nama menu...',
            'all' => $lang == 'en' ? 'All' : 'Semua',
            'currency' => 'Rp ',
            'empty' => $lang == 'en' ? 'No items found.' : 'Tidak ada menu yang ditemukan.',
            'not_found' => $lang == 'en' ? 'Store Not Found' : 'Toko Tidak Ditemukan',
            'not_found_desc' => $lang == 'en' ? 'The store link you are trying to visit does not exist or is inactive.' : 'Tautan toko yang Anda tuju tidak tersedia atau sudah tidak aktif.',
            'submit' => $lang == 'en' ? 'Submit' : 'Kirim',
            'register_member' => $lang == 'en' ? 'Register as Member' : 'Daftar Member',
            'name' => $lang == 'en' ? 'Full Name' : 'Nama Lengkap',
            'phone' => $lang == 'en' ? 'WhatsApp Number' : 'Nomor WhatsApp',
            'date' => $lang == 'en' ? 'Date' : 'Tanggal',
            'time' => $lang == 'en' ? 'Time' : 'Waktu',
            'people' => $lang == 'en' ? 'Number of People' : 'Jumlah Orang',
            'notes' => $lang == 'en' ? 'Notes' : 'Catatan',
            'success' => $lang == 'en' ? 'Success!' : 'Berhasil!',
            'error' => $lang == 'en' ? 'Error!' : 'Gagal!',
            'share' => $lang == 'en' ? 'Share' : 'Bagikan',
        ];
    @endphp

    @if ($notFound)
    <div class="container" style="display:flex; flex-direction:column; align-items:center; justify-content:center; text-align:center; padding:40px 20px;">
        <i data-lucide="store" style="width:64px; height:64px; color:var(--text-muted); margin-bottom:16px;"></i>
        <h1 class="font-bold" style="font-size:24px; margin-bottom:8px;">{{ $t['not_found'] }}</h1>
        <p class="text-muted">{{ $t['not_found_desc'] }}</p>
    </div>
    @else

    <div class="container">
        <!-- Header -->
        <div class="header">
            <div class="store-profile">
                @if ($company->logo_url)
                    <img src="{{ $company->logo_url }}" alt="{{ $company->name }}" class="store-logo">
                @else
                    <div class="store-logo-placeholder">{{ strtoupper(substr($company->name, 0, 1)) }}</div>
                @endif
                <div class="store-info">
                    <h1 class="store-name">{{ $company->name }}</h1>
                    <p class="store-desc">{{ $company->qr_menu_description }}</p>
                </div>
            </div>
            <div class="flex items-center" style="gap:12px;">
                <button onclick="shareLink()" class="cat-btn flex items-center" style="gap:6px;">
                    <i data-lucide="share-2" style="width:14px; height:14px;"></i> {{ $t['share'] }}
                </button>
            </div>
        </div>

        <!-- Sticky Tabs -->
        <div class="nav-tabs">
            <button class="tab-btn active" onclick="switchTab('menu')">{{ $t['menu'] }}</button>
            @if ($company->is_membership_enabled)
                <button class="tab-btn" onclick="switchTab('member')">{{ $t['member'] }}</button>
            @endif
            @if ($company->is_reservation_enabled)
                <button class="tab-btn" onclick="switchTab('reservation')">{{ $t['reservation'] }}</button>
            @endif
        </div>

        <!-- MENU TAB -->
        <div id="tab-menu" class="section-content">
            <div class="search-box">
                <i data-lucide="search" class="search-icon"></i>
                <input type="text" id="searchInput" class="search-input" placeholder="{{ $t['search'] }}">
            </div>

            <div class="categories">
                <button class="cat-btn active" data-cat="all">{{ $t['all'] }}</button>
                @foreach ($categories as $cat)
                    <button class="cat-btn" data-cat="{{ $cat }}">{{ $cat }}</button>
                @endforeach
            </div>

            <div class="menu-grid" id="menuGrid">
                @foreach ($products as $prod)
                    <div class="product-card" data-name="{{ strtolower($prod->name) }}" data-category="{{ $prod->category ?? '' }}" onclick="showProduct({{ $prod->id }})">
                        <div class="product-img-box">
                            @if ($prod->image_path)
                                <img src="{{ url('storage/' . $prod->image_path) }}" class="product-img" loading="lazy">
                            @else
                                <div style="width:100%; height:100%; display:flex; align-items:center; justify-content:center; color:var(--text-muted);">
                                    <i data-lucide="image" style="width:32px; height:32px; opacity:0.3;"></i>
                                </div>
                            @endif
                        </div>
                        <div class="product-info">
                            <h3 class="product-title">{{ $prod->name }}</h3>
                            <p class="product-price">{{ $t['currency'] }}{{ number_format($prod->price, 0, ',', '.') }}</p>
                        </div>
                    </div>
                @endforeach
            </div>
            
            <div id="emptyState" class="hidden" style="text-align:center; padding:40px 0; color:var(--text-muted);">
                <i data-lucide="search-x" style="width:48px; height:48px; margin:0 auto 12px; opacity:0.5;"></i>
                <p>{{ $t['empty'] }}</p>
            </div>
        </div>

        <!-- MEMBER TAB -->
        @if ($company->is_membership_enabled)
        <div id="tab-member" class="section-content hidden">
            <div style="background:var(--card-bg); border:1px solid var(--border-color); border-radius:var(--radius-lg); padding:24px;">
                <h2 class="font-bold" style="font-size:1.125rem; margin-bottom:16px;">{{ $t['register_member'] }}</h2>
                <form id="memberForm" onsubmit="submitMember(event)">
                    <div class="form-group">
                        <label class="form-label">{{ $t['name'] }}</label>
                        <input type="text" id="m_name" class="form-input" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">{{ $t['phone'] }}</label>
                        <input type="tel" id="m_phone" class="form-input" placeholder="08..." required>
                    </div>
                    <button type="submit" class="btn-primary">{{ $t['submit'] }}</button>
                </form>
            </div>
        </div>
        @endif

        <!-- RESERVATION TAB -->
        @if ($company->is_reservation_enabled)
        <div id="tab-reservation" class="section-content hidden">
            <div style="background:var(--card-bg); border:1px solid var(--border-color); border-radius:var(--radius-lg); padding:24px;">
                <h2 class="font-bold" style="font-size:1.125rem; margin-bottom:8px;">{{ $t['reservation'] }}</h2>
                <p class="text-sm text-muted" style="margin-bottom:20px;">{{ $company->reservation_description }}</p>
                
                <form id="reservationForm" onsubmit="submitReservation(event)">
                    <div class="form-group">
                        <label class="form-label">{{ $t['name'] }}</label>
                        <input type="text" id="r_name" class="form-input" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">{{ $t['phone'] }}</label>
                        <input type="tel" id="r_phone" class="form-input" placeholder="08..." required>
                    </div>
                    <div style="display:flex; gap:12px;">
                        <div class="form-group" style="flex:1;">
                            <label class="form-label">{{ $t['date'] }}</label>
                            <input type="date" id="r_date" class="form-input" required min="{{ date('Y-m-d') }}">
                        </div>
                        <div class="form-group" style="flex:1;">
                            <label class="form-label">{{ $t['time'] }}</label>
                            <input type="time" id="r_time" class="form-input" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">{{ $t['people'] }}</label>
                        <input type="number" id="r_people" class="form-input" min="1" value="2" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">{{ $t['notes'] }} (Optional)</label>
                        <textarea id="r_notes" class="form-input" rows="3"></textarea>
                    </div>
                    <button type="submit" class="btn-primary">{{ $t['submit'] }}</button>
                </form>
            </div>
        </div>
        @endif

    </div>

    <!-- Modals -->
    <div class="modal-overlay" id="productModal" onclick="closeModal('productModal')">
        <div class="modal-content" onclick="event.stopPropagation()">
            <button class="modal-close" onclick="closeModal('productModal')"><i data-lucide="x" style="width:16px; height:16px;"></i></button>
            <div id="productModalBody"></div>
        </div>
    </div>

    <script>
        lucide.createIcons();

        const products = @json($products);
        const slug = '{{ $company ? $company->slug : "" }}';

        function shareLink() {
            if (navigator.share) {
                navigator.share({
                    title: '{{ $company ? $company->name : "" }}',
                    url: window.location.href
                });
            } else {
                navigator.clipboard.writeText(window.location.href);
                Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'Link copied!', showConfirmButton: false, timer: 2000 });
            }
        }

        function switchTab(tabId) {
            document.querySelectorAll('.section-content').forEach(el => el.classList.add('hidden'));
            document.querySelectorAll('.tab-btn').forEach(el => el.classList.remove('active'));
            
            document.getElementById('tab-' + tabId).classList.remove('hidden');
            event.currentTarget.classList.add('active');
        }

        const searchInput = document.getElementById('searchInput');
        const catBtns = document.querySelectorAll('.cat-btn[data-cat]');
        const productCards = document.querySelectorAll('.product-card');
        const emptyState = document.getElementById('emptyState');
        let currentCat = 'all';

        if (searchInput) {
            searchInput.addEventListener('input', filterProducts);
        }

        catBtns.forEach(btn => {
            btn.addEventListener('click', (e) => {
                catBtns.forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
                currentCat = e.target.getAttribute('data-cat');
                filterProducts();
            });
        });

        function filterProducts() {
            const query = searchInput ? searchInput.value.toLowerCase() : '';
            let count = 0;

            productCards.forEach(card => {
                const name = card.getAttribute('data-name');
                const cat = card.getAttribute('data-category');
                
                const matchName = name.includes(query);
                const matchCat = currentCat === 'all' || cat === currentCat;

                if (matchName && matchCat) {
                    card.style.display = 'flex';
                    count++;
                } else {
                    card.style.display = 'none';
                }
            });

            if (emptyState) {
                emptyState.classList.toggle('hidden', count > 0);
            }
        }

        function showProduct(id) {
            const product = products.find(p => p.id === id);
            if (!product) return;
            
            let html = `
                <div style="text-align:center; margin-bottom:16px;">
                    ${product.image_path ? `<img src="/storage/${product.image_path}" style="width:100%; max-height:240px; object-fit:cover; border-radius:var(--radius-md); margin-bottom:16px;">` : ''}
                    <h2 class="font-bold" style="font-size:1.25rem;">${product.name}</h2>
                    <p class="font-bold text-primary" style="font-size:1.125rem; margin-top:8px;">{{ $t['currency'] }}${parseInt(product.price).toLocaleString('id-ID')}</p>
                </div>
            `;

            if (product.variants && product.variants.length > 0) {
                html += `<div style="margin-top:20px;">
                    <h4 class="font-semibold" style="margin-bottom:8px;">Varian:</h4>
                    <ul style="list-style:none; padding:0;">`;
                product.variants.forEach(v => {
                    html += `<li style="padding:10px; border:1px solid var(--border-color); border-radius:8px; margin-bottom:8px; display:flex; justify-content:space-between;">
                        <span>${v.name}</span>
                        <span class="font-bold">+{{ $t['currency'] }}${parseInt(v.additional_price).toLocaleString('id-ID')}</span>
                    </li>`;
                });
                html += `</ul></div>`;
            }

            document.getElementById('productModalBody').innerHTML = html;
            document.getElementById('productModal').classList.add('active');
        }

        function closeModal(id) {
            document.getElementById(id).classList.remove('active');
        }

        async function submitMember(e) {
            e.preventDefault();
            const btn = e.target.querySelector('button');
            btn.disabled = true;
            btn.innerHTML = '...';

            try {
                const res = await fetch(`/public/members/${slug}`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
                    body: JSON.stringify({
                        name: document.getElementById('m_name').value,
                        phone: document.getElementById('m_phone').value,
                    })
                });
                const data = await res.json();
                
                Swal.fire({
                    icon: res.ok ? 'success' : 'error',
                    title: res.ok ? '{{ $t['success'] }}' : '{{ $t['error'] }}',
                    text: data.message
                });
                
                if (res.ok) e.target.reset();
            } catch (err) {
                Swal.fire({ icon: 'error', text: 'Connection error' });
            } finally {
                btn.disabled = false;
                btn.innerHTML = '{{ $t['submit'] }}';
            }
        }

        async function submitReservation(e) {
            e.preventDefault();
            const btn = e.target.querySelector('button');
            btn.disabled = true;
            btn.innerHTML = '...';

            try {
                const res = await fetch(`/public/reservations/${slug}`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
                    body: JSON.stringify({
                        customer_name: document.getElementById('r_name').value,
                        customer_phone: document.getElementById('r_phone').value,
                        reservation_date: document.getElementById('r_date').value,
                        reservation_time: document.getElementById('r_time').value,
                        number_of_people: document.getElementById('r_people').value,
                        notes: document.getElementById('r_notes').value,
                    })
                });
                const data = await res.json();
                
                Swal.fire({
                    icon: res.ok ? 'success' : 'error',
                    title: res.ok ? '{{ $t['success'] }}' : '{{ $t['error'] }}',
                    text: data.message
                });
                
                if (res.ok) e.target.reset();
            } catch (err) {
                Swal.fire({ icon: 'error', text: 'Connection error' });
            } finally {
                btn.disabled = false;
                btn.innerHTML = '{{ $t['submit'] }}';
            }
        }
    </script>
    @endif
</body>
</html>
